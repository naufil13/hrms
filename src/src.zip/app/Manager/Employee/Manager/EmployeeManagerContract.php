<?php


namespace App\Manager\Employee\Manager;


interface EmployeeManagerContract
{
    public function assignEmployees($employees);
}