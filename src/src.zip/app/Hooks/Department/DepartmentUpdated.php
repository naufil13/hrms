<?php


namespace App\Hooks\Department;


use App\Helpers\Core\Traits\InstanceCreator;
use App\Hooks\HookContract;

class DepartmentUpdated extends HookContract
{
    use InstanceCreator;

    public function handle()
    {

    }
}
