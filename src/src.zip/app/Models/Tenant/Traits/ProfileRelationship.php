<?php


namespace App\Models\Tenant\Traits;


use App\Models\Tenant\Employee\Department;
use App\Models\Tenant\Employee\Designation;

trait ProfileRelationship
{

}
