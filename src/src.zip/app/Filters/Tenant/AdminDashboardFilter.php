<?php


namespace App\Filters\Tenant;


use App\Filters\FilterBuilder;

class AdminDashboardFilter extends FilterBuilder
{

}