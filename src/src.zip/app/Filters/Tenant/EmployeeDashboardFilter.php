<?php


namespace App\Filters\Tenant;


use App\Filters\FilterBuilder;

class EmployeeDashboardFilter extends FilterBuilder
{

}