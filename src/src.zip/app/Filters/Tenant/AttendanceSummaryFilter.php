<?php


namespace App\Filters\Tenant;


class AttendanceSummaryFilter extends AttendanceDailLogFilter
{

}